================================================================================
                       David Esperalta's Products Keygen
================================================================================

1. RELEASE INFO
2. TARGET INFO
3. TARGET DESCRIPTION
4. HOW TO USE
5. ABOUT ANTIVIRUS AND COMPRESSED BINARIES
6. DISCLAIMER
7. FEEDBACK & CONTACT


================================================================================
1. RELEASE INFO
================================================================================

> Date......: 28/04/2016
> Version...: 1.1
> File......: Keygen.exe
> MD5.......: d75c20edb51dc9746bd1278be2e50ef8
> SHA-1.....: 65805f4c4de63f7a728a6083c95ab23ca1b6a4c9


================================================================================
2. TARGET INFO
================================================================================

> Category..: (multi)
> Protection: Serial
> OS........: WinALL
> Homepage..: http://davidesperalta.com/?languageCode=en&redirectUrl=


================================================================================
3. TARGET DESCRIPTION
================================================================================

                                [ App Builder ]

Complete suite to create HTML5 and hybrid mobile applications.

- Visual designer: App Builder provide us with dozens of visual and non visual
  controls we can simply drop it in the application's designer. Timers, HTTP
  Clients, Text Inputs, Push Buttons and many more controls ready to use.

- Based in actions: You no need to know Javascript to create applications. App
  Builder scripting is based in visual assisted actions that we can use to do
  whatever we wanted. Hundreds of actions are available out of the box.
  Fully extensible: App Builder's applications can be extended in many ways. We
  can use Javascript in addition to the action's based script. We can develop
  and use third party App Builder's Javascript plugins and also Apache Cordova�
  plugins. 

DOWNLOAD: http://davidesperalta.com/Humm/Sites/Main/Views/Files/AppBuilder.zip


                               [ HTML Compiler ]

HTML applications into standalone Microsoft Windows� executables.

- It's secure: Your HTML application is compiled into and standalone Microsoft
  Windows� executable without dependencies. Your application's files are never
  extracted into the final user computer.

- Easy & fast: Using the program GUI or the Command Line Interface version we
  can compile HTML applications in seconds by just telling the program the place
  of our HTML application's index file.

- Customizable: HTML Compiler is (really) fully customizable and include dozens
  of interface themes we can use in HTML Compiler and our application Microsoft
  Windows� executables too. 

DOWNLOAD: http://davidesperalta.com/Humm/Sites/Main/Views/Files/HtmlCompiler.zip


                               [ Img Converter ]

Convert images from up to 23 input formats and up to 18 output formats.

- Automatic: Once your configure the output directory (your desktop by default)
  and choose the format you wanted (all of them by default) you just need to
  drop image files into the program window.

DOWNLAOD: http://davidesperalta.com/Humm/Sites/Main/Views/Files/ImgConverter.zip


                                 [ Screen GIF ]

Easy way to grab your selected screen area into animated GIF images.

- Very easy: Press the Start button to grab the selected screen area. Press the
  stop button to stop the capture and begin to edit the animated GIF. That's
  all! Then your GIF is ready to be shared.

- Optimized: Screen GIF optimize by default the generated GIF image and we
  optionally can grab the screen scaled by certain percentage and grayscale
  colors, then our GIFs remains smaller as possible. 

DOWNLOAD: http://davidesperalta.com/Humm/Sites/Main/Views/Files/ScreenGif.zip


                                [ Small Editor ]

Small but powerful text and source code editor for a daily usage.

- Small but...: Small Editor start fast as a better replacement for the Windows�
  Notepad. It's useful to work with TXT files and also source code files,
  because the recognition of dozens of programming languages syntax.
  
- Very powerful: Plenty of features like text search and replace in files,
  complete preview and print engine, remote files edition via FTP, support for
  plugins, including various of them out of the box and many, many more. 

DOWNLOAD: http://davidesperalta.com/Humm/Sites/Main/Views/Files/SmallEditor.zip


                                [ Volume Keys ]

Change your speakers' volume with your predefined keyboard hotkeys.

- Customizable: Volume Keys run out of the box with the F6 key to volume down,
  F7 to volume up and F8 to volume mute. We can customize this keys with our
  own ones to perform the volume changes.

- Screen Display: The program shown On Screen Display messages to inform us
  about the current speakers' volume state and percentage, no matter if we are
  playing a game at full screen, for example. 

DOWNLOAD: http://davidesperalta.com/Humm/Sites/Main/Views/Files/VolumeKeys.zip


================================================================================
4. HOW TO USE
================================================================================

1. Select the target product.

2. Enter any name with at least 25 chars length.

3. Click "Generate" button. Use "Copy" button to copy the serial number to
   clipboard.

4. Use the generated serial number register the program.


================================================================================
5. ABOUT ANTIVIRUS AND COMPRESSED BINARIES
================================================================================

This release's binary is packed with an executable/dll compression tool to
reduce his size (for an easy and quick upload/download).

Unfortunatly, some of these compression programs have a bad reputation in the
security software industry, mainly because almost 99% of troyans/worms/etc.
is packed with similar tools (or variants of these), and this self-unpack
behavior is taken by some antivirus apps as an alarm signal.

Basically, this means that any trusted program packed with one of these tools
can be erroneously detected as a virus, something know as a "FAKE POSITIVE".

********************************************************************************
IMPORTANT: If you got this release from me, from the site indicated at the end
of this document or from any file server explicitly expressed by me; ignore any
warning from your antivirus software (most certainly it's a fake positive).

IF YOU GOT THIS FROM ELSEWHERE, THERE IS NO WARRANTY THAT YOUR COPY WILL BE FREE
OF ANY THREAT; IN THAT CASE, I WILL NOT BE RESPONSIBLE FOR ANY DAMAGED CAUSED
TO YOUR COMPUTER. YOU HAVE BEEN WARNED.
********************************************************************************

However, you can always do a simple integrity check: get the MD5 or SHA1 hash
value for this release's binary and compare it against the value written at the
top of this document. Any difference between the hash values means that the
executable file was somehow modified/tampered. It's very simple.

There are plenty of free tools around the net that you can use to verify file
hashes, like HashTab (http://implbits.com) or HashMyFiles
(http://www.nirsoft.net). This test isn't a foolproof concept, but can help.


================================================================================
6. DISCLAIMER
================================================================================

This program is provided "AS IS" without any warranty, either expressed or
implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. I take no responsibility
for any damage that may unintentionally be caused through its use.

I'm just a fan of RCE and i do this for recreation/hobby. You can use this
program for evaluation purposes ONLY. You are not allowed to get a monetary
profit of any kind through its use.


================================================================================
7. FEEDBACK & CONTACT
================================================================================

For updates, latest releases or to contact me, use the links below. Any thought
or question (please, don't send me requests) is always welcome.

> Find me at: http://www.nsaneforums.com
> My profile: http://www.nsaneforums.com/user/82845-radixx11

  
================================================================================
                               (c) 2016, RadiXX11
================================================================================